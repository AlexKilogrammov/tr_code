#include <chrono>
#include <memory>
#include <thread>
#include <vector>
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <qluacpp/qlua>
#include <iostream>
#include "model1.hpp"
#include "gui.hpp"
#include "gui1.hpp"
#include "wa_table.hpp"
#include "bot.hpp"
#include "state.hpp"
#include "status.hpp"

QuikConnector Q;

static std::shared_ptr<model> m;
static std::shared_ptr<model1> m1;

static size_t depth_count{ 3 };
static bool done{ false };
static std::string sec_class{ "TQBR" };
static std::string sec_code{ "SBER" };
static std::string sec_class1{ "TQBR" };
static std::string sec_code1{ "GAZP" };
static wa_table table;
static wa_table1 table1;


using std::vector;
std::vector<double> Last_;
std::vector<double> _x;
std::vector<double> _x1;


bot& bot::instance() {
	static bot b;
	return b;
}

/*void bot::set_lua_state(const lua::state& l) {
	l_ = l;
	q_trade_ = std::unique_ptr<qlua::extended>(new qlua::extended(l));
}*/

void bot::my_main(lua::state& l)
{

	using namespace std::chrono_literals;
	qlua::api q(l);
	//q.CalcBuySell("TQBR", "SBER", "308897", "L01+00000F00", 252.5, "B", "1");
	

	table.create(q, ("Average L2Q for " + sec_class + ":" + sec_code + "DEPTH " + std::to_string(depth_count)).c_str());
	table1.create1(q, ("Average L2Q for 1" + sec_class1 + ":" + sec_code1 + "DEPTH " + std::to_string(depth_count)).c_str());
	if (q.Subscribe_Level_II_Quotes("TQBR", "SBER") && q.Subscribe_Level_II_Quotes("TQBR", "GAZP")) {
		m = std::shared_ptr<model>(new model(q, sec_class, sec_code, q.constant<unsigned int>("INTERVAL_D1"), 50));
		m1 = std::shared_ptr<model1>(new model1(q, sec_class1, sec_code1, q.constant<unsigned int>("INTERVAL_D1"), 50));
		try {
			gui::instance().data_unavailable_text() = { "Data is not available..." };
			gui::instance().create("QluaCPP RT candles demo - " + sec_class + ":" + sec_code, m);
			gui1::instance1().data_unavailable_text1() = { "Data is not available..." };
			gui1::instance1().create1("QluaCPP RT candles demo 1 - " + sec_class1 + ":" + sec_code1, m1);
		}
		catch (std::runtime_error e) {
			q.message((std::string("qluacpp rt candles demo failed to create gui window: ")
				+ e.what()).c_str());
			return;
		}
		while (!done || !gui::instance().done_) {
			std::this_thread::sleep_for(100ms);
		}
	}
	else {
		q.message(("Could not subscribe to " + sec_class + ":" + sec_code).c_str());
		//q.message(("Could not subscribe to " + sec_class1 + ":" + sec_code1).c_str());
	}

	/*static std::string sec_class{ "TQBR" };
	static std::string sec_code{ "SBER" };
	m = std::shared_ptr<model>(new model(q, sec_class, sec_code, q.constant<unsigned int>("INTERVAL_M1"), 50));
	try {
		gui::instance().data_unavailable_text() = { "Data is not available..." };
		gui::instance().create("QluaCPP RT candles demo - " + sec_class + ":" + sec_code, m);
	}
	catch (std::runtime_error e) {
		q.message((std::string("qluacpp rt candles demo failed to create gui window: ")
			+ e.what()).c_str());
		return;
	}
	while (!gui::instance().done_) {
		std::this_thread::sleep_for(100ms);
	}*/
}

std::tuple<int> bot::OnStop(const lua::state& l, ::lua::entity<::lua::type_policy<int>> signal) 
{
	m = nullptr;
	gui::instance().terminate();
	gui1::instance1().terminate1();
	return std::make_tuple(int(1));
}

void bot::qluacpp_candles_cb(const lua::state&l, const ::lua::entity<::lua::type_policy<unsigned int>> idx) {
	m->update(idx(), _x); //, Closing_Price

}

void bot::qluacpp_candles_cb1(const lua::state&l, const ::lua::entity<::lua::type_policy<unsigned int>> idx1) {
	m1->update1(idx1(), _x1); //, Closing_Price
}

void bot::OnQuote(const lua::state& l, ::lua::entity<::lua::type_policy<const char*>> quote_sec_class, ::lua::entity<::lua::type_policy<const char*>> quote_sec_code)
{	
	if ((quote_sec_class() == sec_class) && (quote_sec_code() == sec_code)) {
		qlua::api q(l);
		/*q_trade_ = std::unique_ptr<qlua::extended>(new qlua::extended(l));
		std::map<std::string, std::string> trans = {
			{ "ACCOUNT", "L01+00000F00" },
			{ "CLIENT_CODE", "308897" },
			{ "CLASSCODE", "TQBR" },
			{ "SECCODE", "SBER" },
			{ "TRANS_ID", "0" },
			{ "QUANTITY", "1" },
			{ "OPERATION", "B" },
			{ "PRICE",  "1" },
			{ "ACTION", "NEW_ORDER" }
		};*/
		//q_trade_ ->sendTransaction(trans);
		
		q.getQuoteLevel2(quote_sec_class(), quote_sec_code(),
			[&q](const ::qlua::table::level2_quotes& quotes) {
			auto bid = quotes.bid();
			auto offer = quotes.offer();
			double bid_quant{ 0.0 };
			double bid_wap{ 0.0 };
			double offer_quant{ 0.0 };
			double offer_wap{ 0.0 };

			auto& oo = offer[0];
			double _Y = atof(oo.price.c_str());
			auto& bb = bid[0];
			double _X = atof(bb.price.c_str());

			Q.MidMarket(_Y, _X);

			q.message(("Quote " + sec_code + "; " + oo.price.c_str() + ":").c_str());

			if ((depth_count <= bid.size()) && (depth_count <= offer.size())) {
				for (size_t i = 0; i < depth_count; ++i) {
					auto& b = bid[bid.size() - 1 - i];
					const double bq = atof(b.quantity.c_str());
					bid_quant += bq;
					bid_wap += atof(b.price.c_str()) * bq;
					auto& o = offer[i];
					const double oq = atof(o.quantity.c_str());
					offer_quant += oq;
					offer_wap += atof(o.price.c_str()) * oq;
				}
				bid_wap = bid_wap / bid_quant;
				offer_wap = offer_wap / offer_quant;
				table.update(q, _Y, bid_quant, _X, offer_quant, _x);  //table.update(q, bid_wap, bid_quant, offer_wap, offer_quant);
			}

		});
	}
	/*else if((quote_sec_class() == sec_class1) && (quote_sec_code() == sec_code1)) {
		qlua::api q(l);
		q.getQuoteLevel2(quote_sec_class(), quote_sec_code(),
			[&q](const ::qlua::table::level2_quotes& quotes) {
			auto bid = quotes.bid();
			auto offer = quotes.offer();
			double bid_quant{ 0.0 };
			double bid_wap{ 0.0 };
			double offer_quant{ 0.0 };
			double offer_wap{ 0.0 };

			auto& oo = offer[0];
			double _Y = atof(oo.price.c_str());
			auto& bb = bid[0];
			double _X = atof(bb.price.c_str());

			Q.MidMarket(_Y, _X);

			q.message(("Quote " + sec_code1 + "; " + oo.price.c_str() + ":").c_str());

			if ((depth_count <= bid.size()) && (depth_count <= offer.size())) {
				for (size_t i = 0; i < depth_count; ++i) {
					auto& b = bid[bid.size() - 1 - i];
					const double bq = atof(b.quantity.c_str());
					bid_quant += bq;
					bid_wap += atof(b.price.c_str()) * bq;
					auto& o = offer[i];
					const double oq = atof(o.quantity.c_str());
					offer_quant += oq;
					offer_wap += atof(o.price.c_str()) * oq;
				}
				bid_wap = bid_wap / bid_quant;
				offer_wap = offer_wap / offer_quant;
				table.update(q, _Y, bid_quant, _X, offer_quant, _x1);  //table.update(q, bid_wap, bid_quant, offer_wap, offer_quant);
			}

		});
	}*/
}

void bot::OnQuote1(const lua::state& l, ::lua::entity<::lua::type_policy<const char*>> quote_sec_class1, ::lua::entity<::lua::type_policy<const char*>> quote_sec_code1)
{
	/*quote_sec_class1() = sec_class1.c_str();
	quote_sec_code1() == sec_code1.c_str();*/
	//if ((quote_sec_class1() == sec_class1) && (quote_sec_code1() == sec_code1)) {		
		qlua::api q(l);	
		//	quote_sec_class1() =	std::string sec_class1{ "TQBR" };
		table1.update1(q, 0, 0, 0, 0, _x1);
		q.getQuoteLevel2(sec_class1.c_str(), sec_code1.c_str(),
			[&q](const ::qlua::table::level2_quotes& quotes) {
			auto bid = quotes.bid();
			auto offer = quotes.offer();
			double bid_quant{ 0.0 };
			double bid_wap{ 0.0 };
			double offer_quant{ 0.0 };
			double offer_wap{ 0.0 };

			auto& oo = offer[0];
			double _Y = atof(oo.price.c_str());
			auto& bb = bid[0];
			double _X = atof(bb.price.c_str());

			Q.MidMarket(_Y, _X);

			q.message(("Quote " + sec_code1 + "; " + oo.price.c_str() + ":").c_str());

			if ((depth_count <= bid.size()) && (depth_count <= offer.size())) {
				for (size_t i = 0; i < depth_count; ++i) {
					auto& b = bid[bid.size() - 1 - i];
					const double bq = atof(b.quantity.c_str());
					bid_quant += bq;
					bid_wap += atof(b.price.c_str()) * bq;
					auto& o = offer[i];
					const double oq = atof(o.quantity.c_str());
					offer_quant += oq;
					offer_wap += atof(o.price.c_str()) * oq;
				}
				bid_wap = bid_wap / bid_quant;
				offer_wap = offer_wap / offer_quant;
				table1.update1(q, _Y, bid_quant, _X, offer_quant, _x1);  //table.update(q, bid_wap, bid_quant, offer_wap, offer_quant);
			}

		});
	//}
	
}

////////////////////////////////////////////////////////////////

void bot::thread_unsafe_main(const lua::state& l) {
	auto &b = bot::instance();
	b.state_->set_lua_state(l);
	if (b.refresh_instruments) {
		std::cout << "Refreshing instruments" << std::endl;
		b.state_->refresh_available_instrs();
		// For trading in Quik Junior emulator, remove otherwise
		b.state_->filter_available_instrs_quik_junior();
	}

	if (b.select_candidates) {
		std::cout << "Selecting candidates" << std::endl;
		b.state_->choose_candidates();
	}

	if (b.update_status) {
		std::cout << "Updating status" << std::endl;
		b.status_->set_lua_state(l);
		b.status_->update();
	}
}

std::tuple<bool> bot::thread_safe_main(const lua::state& l,	::lua::entity<::lua::type_policy<const int>>, ::lua::entity<::lua::type_policy<const int>>) {
	thread_unsafe_main(l);
	return std::make_tuple(bool{ true });
}

/*
std::tuple<bool> bot::thread_safe_cv_notify(const lua::state& l,
											::lua::entity<::lua::type_policy<const int>>,
											::lua::entity<::lua::type_policy<const int>>) {
  auto& b = bot::instance();
  b.cv_.notify_one();
  return std::make_tuple(bool{true});
  }*/

std::tuple<int> bot::on_stop(const lua::state& l, ::lua::entity<::lua::type_policy<int>> signal) {
	std::cout << "on stop " << std::endl;
	auto& b = bot::instance();
	b.state_->set_lua_state(l);
	b.state_->on_stop();
	b.status_->set_lua_state(l);
	b.status_ = nullptr;
	b.terminated = true;
	b.cv_.notify_one();
	std::unique_lock<std::mutex> lock(b.stop_mutex_);
	std::cout << "Waiting for main to stop" << std::endl;
	b.stop_cv_.wait(lock, [&b]() { return b.main_stopped == true; });
	std::cout << "Main stopped" << std::endl;
	lock.unlock();
	return std::make_tuple(int(1));
}

void bot::on_connected(const lua::state& l, ::lua::entity<::lua::type_policy<bool>> new_class_received) {
	std::cout << "on connected " << std::endl;
	auto& b = bot::instance();
	if (new_class_received()) {
		b.refresh_instruments = true;
		b.select_candidates = true;
		b.cv_.notify_one();
	}
}

void bot::on_order(const lua::state& l, ::lua::entity<::lua::type_policy<::qlua::table::orders>> order) {
	std::cout << "OnOrder" << std::endl;
	auto& b = bot::instance();
	b.state_->set_lua_state(l);
	b.state_->on_order(order().trans_id(),
		order().order_num(),
		order().flags(),
		order().qty(),
		order().balance(),
		order().price());
	b.update_status = true;
	b.cv_.notify_one();
	std::cout << "OnOrder done" << std::endl;
}

void bot::on_quote(const lua::state& l,	::lua::entity<::lua::type_policy<const char*>> sec_class, ::lua::entity<::lua::type_policy<const char*>> sec_code) {
	std::cout << "OnQuote" << std::endl;
	auto& b = bot::instance();
	b.state_->set_lua_state(l);
	b.state_->on_quote(std::string(sec_class()), std::string(sec_code()));
	std::cout << "OnQuote requesting update status" << std::endl;
	b.update_status = true;
	b.cv_.notify_one();
	std::cout << "OnQuote done" << std::endl;
}

void bot::on_trans_reply(const lua::state& l,
	::lua::entity<::lua::type_policy<::qlua::table::trans_reply>> reply) {
	std::cout << "OnTransReply:" << std::endl;
	std::cout << "  trans_id " << reply().trans_id() << std::endl;
	std::cout << "  status " << reply().status() << std::endl;
	std::cout << "  result_msg " << reply().result_msg() << std::endl;
	try {
		std::cout << "  date_time date " << reply().date_time().year << std::endl;
	}
	catch (std::runtime_error e) {
		std::cout << "\n Could not get date_time - " << e.what() << "\n";
	}
	std::cout << "  uid " << reply().uid() << std::endl;
	std::cout << "  flags " << reply().flags() << std::endl;
	std::cout << "  server_trans_id " << reply().server_trans_id() << std::endl;
}


void bot::terminate(const qlua::api& q, const std::string& msg) {
	if (msg.size() > 0) {
		q.message(msg.c_str());
	}
	auto& b = bot::instance();
	b.instance().terminated = true;
	b.cv_.notify_one();
}

settings_record& bot::settings() {
	return settings_;
}

const std::unique_ptr<state>& bot::get_state() {
	return state_;
}
