#include "gui1.hpp"
#include "windows.h"
#include <algorithm>
#include <cmath>
#include <thread>

paintable1::paintable1(const model1& m1,
	const int x1,
	const int y1,
	const int width1,
	const int height1,
	const int spacing1,
	const int candle_width1) :
	m_1(m1),
	x_1(x1),
	y_1(y1),
	width_1(width1),
	height_1(height1),
	spacing_1(spacing1),
	candle_width_1(candle_width1) {

}

void chart_area1::paint1(void* paintstruct1) const {
	//  paint_grid(paintstruct);
	paint_candles1(paintstruct1);
}

void chart_area1::paint_candles1(void* paintstruct1) const {
	auto ps1 = (PAINTSTRUCT*)paintstruct1;
	const auto& cs1 = m_1.candles1();
	if (cs1.size() > 1) {
		auto max_price1 = m_1.max_price1();
		auto min_price1 = m_1.min_price1();
		auto price_z1 = max_price1 - min_price1;
		auto max_volume1 = m_1.max_volume1();
		auto min_volume1 = m_1.min_volume1();
		auto volume_z1 = max_volume1 - min_volume1;

		// Close to open lines
		for (size_t i = 0; i < cs1.size() - 1; ++i) {
			double l_close1 = (cs1[i].close1 - min_price1) / price_z1;
			double r_open1 = (cs1[i + 1].open1 - min_price1) / price_z1;
			long left1 = (i * candle_width_1) + candle_width_1 - spacing_1 - 1;
			long right1 = (i + 1) * candle_width_1 + spacing_1 + 1;
			std::vector<POINT> line_points1{
			  {abs_x1(left1), abs_y1(height_1 - std::lround(l_close1 * height_1))},
				{abs_x1(right1), abs_y1(height_1 - std::lround(r_open1 * height_1))} };
			Polyline(ps1->hdc, line_points1.data(), line_points1.size());
		}

		// Candle bodies
		size_t i{ 0 };
		for (const auto& c1 : cs1) {
			auto open1 = (c1.open1 - min_price1) / price_z1;
			auto close1 = (c1.close1 - min_price1) / price_z1;
			auto high1 = (c1.high1 - min_price1) / price_z1;
			auto low1 = (c1.low1 - min_price1) / price_z1;
			std::vector<double> open_close1{ open1, close1 };
			std::sort(open_close1.begin(), open_close1.end());
			long left1 = i * candle_width_1 + spacing_1;
			long right1 = (i * candle_width_1) + (candle_width_1 - spacing_1);
			long top1 = height_1 - std::lround(open_close1[1] * height_1) - 1;
			long bottom1 = height_1 - std::lround(open_close1[0] * height_1) + 1;

			long v_line_top1 = height_1 - std::lround(high1 * height_1);
			long v_line_bottom1 = height_1 - std::lround(low1 * height_1);
			long middle_x1 = i * candle_width_1 + (candle_width_1 / 2);

			std::vector<POINT> v_line1{ {abs_x1(middle_x1), abs_y1(v_line_top1)}, {abs_x1(middle_x1), abs_y1(v_line_bottom1)} };
			Polyline(ps1->hdc, v_line1.data(), v_line1.size());

			auto vol1 = (c1.volume1 - min_volume1) / volume_z1;
			BYTE red1 = BYTE(std::lround(vol1 * 255.0));
			BYTE blue1 = BYTE(std::lround((1.0 - vol1) * 255.0));
			auto brush1 = CreateSolidBrush(RGB(red1, 128, blue1));
			SelectObject(ps1->hdc, brush1);
			RoundRect(ps1->hdc, abs_x1(left1), abs_y1(top1), abs_x1(right1), abs_y1(bottom1), 3, 3);
			DeleteObject(brush1);
			++i;
		}
	}
}

void chart_bottom1::paint1(void* paintstruct1) const {
	auto ps1 = (PAINTSTRUCT*)paintstruct1;
	const auto& cs1 = m_1.candles1();
	if (cs1.size() > 1) {
		/*
		// Date labels for candles
		// TODO: Rotate labels in separate DCs and copy
		const float factor = (1.0f * 3.1416f) / 360.0f;
		const float rot = 45.0f * factor;
		XFORM oldtransform;
		XFORM xfm = { 0.0f };
		xfm.eM11 = (float)cos(rot);
		xfm.eM12 = (float)sin(rot);
		xfm.eM21 = (float)-sin(rot);
		xfm.eM22 = (float)cos(rot);
		auto old_mode = GetGraphicsMode(ps->hdc);
		SetGraphicsMode(ps->hdc, GM_ADVANCED);
		GetWorldTransform(ps->hdc, &oldtransform);
		SetWorldTransform(ps->hdc, &xfm);
		for (size_t i = 0; i < cs.size(); ++i) {
		  // Write time for every 5 candles
		  if (((i % 5) == 0) || (i == cs.size() - 1)) {
			TextOut(ps->hdc, abs_x(i * candle_width_), abs_y(5), cs[i].time.c_str(), cs[i].time.size());
		  }
		  }

		SetWorldTransform(ps->hdc, &oldtransform);
		SetGraphicsMode(ps->hdc, old_mode); */

		// Last price
		auto max_volume1 = m_1.max_volume1();
		auto min_volume1 = m_1.min_volume1();

		std::string last_str1 = std::to_string(cs1[cs1.size() - 1].close1);
		while ((last_str1.find(".") != std::string::npos) && (last_str1[last_str1.size() - 1] == '0'))
			last_str1 = last_str1.substr(0, last_str1.size() - 1);
		TextOut(ps1->hdc, abs_x1(width_1 - 80), abs_y1(labels_height_1 + 20), last_str1.c_str(), last_str1.size());

		// Volume gauge
		const long x_offset1 = 10;
		std::string vol_txt1{ "Volume:" };
		TextOut(ps1->hdc, abs_x1(x_offset1), abs_y1(labels_height_1), vol_txt1.c_str(), vol_txt1.size());
		std::string min_vol_str1 = std::to_string(std::lround(min_volume1));
		std::string max_vol_str1 = std::to_string(std::lround(max_volume1));
		TextOut(ps1->hdc, abs_x1(x_offset1 - 3), abs_y1(labels_height_1 + 5 + 20), min_vol_str1.c_str(), min_vol_str1.size());
		TextOut(ps1->hdc, abs_x1(x_offset1 + 255 - 3), abs_y1(labels_height_1 + 5 + 20), max_vol_str1.c_str(), max_vol_str1.size());
		for (int i = 1; i < 255; ++i) {
			std::vector<POINT> line1{ {abs_x1(x_offset1 + i), abs_y1(labels_height_1 + 50)},
				{abs_x1(x_offset1 + i), abs_y1(labels_height_1 + 75)} };
			auto pen1 = CreatePen(PS_SOLID, 1, RGB(i, 128, 255 - i));
			SelectObject(ps1->hdc, pen1);
			Polyline(ps1->hdc, line1.data(), line1.size());
			DeleteObject(pen1);
		}
		auto pen1 = CreatePen(PS_SOLID, 1, 0);
		SelectObject(ps1->hdc, pen1);
		SelectObject(ps1->hdc, GetStockObject(NULL_BRUSH));
		Rectangle(ps1->hdc, abs_x1(x_offset1), abs_y1(labels_height_1 + 50), abs_x1(x_offset1 + 255), abs_y1(labels_height_1 + 75));
		std::vector<POINT> vol_min_line1{ {abs_x1(x_offset1), abs_y1(labels_height_1 + 50 - 10)},
			{abs_x1(x_offset1), abs_y1(labels_height_1 + 50)} };
		std::vector<POINT> vol_max_line1{ {abs_x1(x_offset1 + 254), abs_y1(labels_height_1 + 50 - 10)},
			{abs_x1(x_offset1 + 254), abs_y1(labels_height_1 + 50)} };
		Polyline(ps1->hdc, vol_min_line1.data(), vol_min_line1.size());
		Polyline(ps1->hdc, vol_max_line1.data(), vol_max_line1.size());
		DeleteObject(pen1);
	}
}

LRESULT CALLBACK wnd_proc1(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
	auto& g1 = gui1::instance1();

	switch (uMsg) {
	case WM_CREATE:
		return 0;
	case WM_PAINT: {
		g1.model_1->wait1();
		PAINTSTRUCT ps1;
		BeginPaint(hwnd, &ps1);

		const auto& cs1 = g1.model_1->candles1();

		if (cs1.size() > 1) {
			if (g1.chart1) g1.chart1->paint1(&ps1);
			if (g1.bottom1) g1.bottom1->paint1(&ps1);
		}
		else {
			long i{ 0 };
			for (const std::string& s1 : g1.data_unavailable_text1()) {
				TextOut(ps1.hdc, 10, 10 + i, s1.c_str(), s1.size());
				i += 18;
			}
		}
		EndPaint(hwnd, &ps1);
		g1.model_1->notify1();
		return 0;
	}
	case WM_SIZE:
		return 0;
	case WM_DESTROY:
		g1.done_1 = true;
		return 0;
	default:
		return DefWindowProc(hwnd, uMsg, wParam, lParam);
	}
	return 0;
}

static std::thread message_thread1;

void thread_proc1() {
	auto hinstance1 = GetModuleHandle(NULL);
	auto& hwnd1 = gui1::instance1().hwnd_1;
	hwnd1 = CreateWindowA(gui1::instance1().wnd_class_1.c_str(),        // name of window class 
		gui1::instance1().title_1.c_str(),            // title-bar string 
		WS_SYSMENU | WS_CAPTION, // top-level window 
		CW_USEDEFAULT,       // default horizontal position 
		CW_USEDEFAULT,       // default vertical position 
		gui1::instance1().wnd_width_1,       // default width 
		gui1::instance1().wnd_height_1,       // default height 
		(HWND)NULL,         // no owner window 
		(HMENU)NULL,        // use class menu 
		hinstance1,           // handle to application instance 
		(LPVOID)NULL);      // no window-creation data
	if (!hwnd1)
		throw std::runtime_error("Could not create window");
	ShowWindow((HWND)hwnd1, SW_SHOWNORMAL);
	UpdateWindow((HWND)hwnd1);

	MSG msg1;
	while (!gui1::instance1().done_1) {
		auto rslt1 = GetMessage(&msg1, (HWND)hwnd1, 0, 0);
		switch (rslt1) {
		case -1:
			return;
		case 0:
			return;
		default:
			TranslateMessage(&msg1);
			DispatchMessage(&msg1);
		}
	}
	hwnd1 = nullptr;
}

gui1& gui1::instance1() {
	static gui1 g1;
	return g1;
}

std::vector<std::string>& gui1::data_unavailable_text1() {
	return data_unavailable_text_1;
}

void gui1::create1(const std::string& title1, std::shared_ptr<model1> m1) {
	if (m1 == nullptr) {
		throw std::runtime_error("Can't create candles window without model");
	}
	if (hwnd_1 != nullptr) {
		PostMessage((HWND)hwnd_1, WM_DESTROY, 0, 0);
	}
	hwnd_1 = nullptr;
	done_1 = false;
	title_1 = title1;
	model_1 = m1;
	auto hinstance1 = GetModuleHandle(NULL);
	auto const chart_height1 = std::lround(wnd_height_1 * 0.4);
	auto const bottom_height1 = std::lround(wnd_height_1 * 0.6);

	chart1 = std::make_unique<chart_area1>(*m1,
		0, 0,
		wnd_width_1 - 6, chart_height1,
		3,
		(wnd_width_1 - 6) / m1->max_count1());
	bottom1 = std::make_unique<chart_bottom1>(*m1,
		0, chart_height1,
		wnd_width_1 - 6, bottom_height1,
		3,
		(wnd_width_1 - 6) / m1->max_count1());

	WNDCLASS wc1;
	if (!GetClassInfo(hinstance1, wnd_class_1.c_str(), &wc1)) {
		// Register the main window class. 
		wc1.style = CS_HREDRAW | CS_VREDRAW;
		wc1.cbClsExtra = 0;
		wc1.cbWndExtra = 0;
		wc1.hInstance = hinstance1;
		wc1.hIcon = LoadIcon(NULL, IDI_APPLICATION);
		wc1.hCursor = LoadCursor(NULL, IDC_ARROW);
		wc1.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
		wc1.lpszMenuName = NULL;
		wc1.lpszClassName = wnd_class_1.c_str();
		wc1.lpfnWndProc = wnd_proc1;

		if (!RegisterClass(&wc1))
			throw std::runtime_error("Could not register window class");
	}
	message_thread1 = std::move(std::thread(thread_proc1));
	message_thread1.detach();

	model_1->wait1();
	model_1->on_new_data1 = [this]() {
		if (hwnd_1 != nullptr) {
			InvalidateRect((HWND)hwnd_1, NULL, true);
			PostMessage((HWND)hwnd_1, WM_PAINT, 0, 0);
		}
	};
	model_1->notify1();
}

void gui1::terminate1() {
	if (hwnd_1 != nullptr) {
		PostMessage((HWND)hwnd_1, WM_DESTROY, 0, 0);
	}
}

int gui1::chart_area_width1() const {
	return wnd_width_1 - 6;
}

int gui1::chart_area_height1() const {
	return wnd_height_1 / 3 * 2;
}

