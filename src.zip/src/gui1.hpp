#pragma once

#include <atomic>
#include "model1.hpp"

struct paintable1 {
	paintable1(const model1& m1,
		const int x1,
		const int y1,
		const int width1,
		const int height1,
		const int spacing1,
		const int candle_width1);

protected:
	int x_1;
	int y_1;
	int width_1;
	int height_1;
	int spacing_1;
	int candle_width_1;

	const model1& m_1;

	inline int abs_x1(int rel_x1) const {
		return x_1 + rel_x1;
	}

	inline int abs_y1(int rel_y1) const {
		return y_1 + rel_y1;
	}

};

struct chart_area1 : paintable1 {
	using paintable1::paintable1;

	void paint1(void* paintstruct1) const;

private:
	void paint_candles1(void* paintstruct1) const;
};

struct chart_bottom1 : paintable1 {
	using paintable1::paintable1;

	void paint1(void* paintstruct1) const;
private:
	int labels_height_1{ 0 };
};

struct gui1 {
	static gui1& instance1();
	void create1(const std::string& title, std::shared_ptr<model1> m1);
	void repaint1();
	void terminate1();

	std::vector<std::string>& gui1::data_unavailable_text1();

	std::shared_ptr<model1> model_1;

	inline int chart_area_width1() const;
	inline int chart_area_height1() const;

	std::string title_1;
	std::string wnd_class_1{ "qluacpp_draw_candles_rt1" };
	void* hwnd_1{ nullptr };
	int wnd_height_1{ 400 };
	int wnd_width_1{ 900 };
	std::atomic<bool> done_1{ false };

	std::unique_ptr<chart_area1> chart1;
	std::unique_ptr<chart_bottom1> bottom1;
private:
	gui1() {};

	std::vector<std::string> data_unavailable_text_1;
};

