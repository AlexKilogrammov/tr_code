#define LUA_LIB
#if defined(WIN32) || defined(_WIN32) || defined(__WIN32)
  #define LUA_BUILD_AS_DLL
#endif

#include <chrono>
#include <memory>
#include <thread>
#include <qluacpp/qlua>

#include "model.hpp"
#include "model1.hpp"
#include "gui.hpp"
#include "gui1.hpp"
#include "wa_table.hpp"
#include "bot.hpp"
/*#include <Eigen/Dense>

using namespace Eigen;*/

static struct luaL_reg ls_lib[] = {
  { NULL, NULL }
};

LUACPP_STATIC_FUNCTION2(main, bot::my_main)
LUACPP_STATIC_FUNCTION3(OnStop, bot::OnStop, int)
LUACPP_STATIC_FUNCTION4(OnQuote, bot::OnQuote, const char*, const char*)
LUACPP_STATIC_FUNCTION4(OnQuote1, bot::OnQuote1, const char*, const char*)
LUACPP_STATIC_FUNCTION3(qluacpp_candles_cb, bot::qluacpp_candles_cb, unsigned int)
LUACPP_STATIC_FUNCTION3(qluacpp_candles_cb1, bot::qluacpp_candles_cb1, unsigned int)
                        
extern "C" {
  LUALIB_API int luaopen_lualib_l2q_wa(lua_State *L) {
    lua::state l(L);

    ::lua::function::main().register_in_lua(l, bot::my_main);
	::lua::function::OnStop().register_in_lua(l, bot::OnStop);
    ::lua::function::OnQuote().register_in_lua(l, bot::OnQuote);
	::lua::function::OnQuote1().register_in_lua(l, bot::OnQuote1);	
	::lua::function::qluacpp_candles_cb().register_in_lua(l, bot::qluacpp_candles_cb);
	::lua::function::qluacpp_candles_cb1().register_in_lua(l, bot::qluacpp_candles_cb1);
	
    luaL_openlib(L, "lualib_l2q_wa", ls_lib, 0);
    return 0;
  }
}
