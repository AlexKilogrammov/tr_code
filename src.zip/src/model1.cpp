#include "model1.hpp"
#include "windows.h"
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <sstream>

model1::model1(const qlua::api& q1,
	const std::string& sec_class1, const std::string& sec_code1, const unsigned int interval1,
	const size_t max_count1) :
	sec_class_1(sec_class1),
	sec_code_1(sec_code1),
	interval_1(interval1),
	max_count_1(max_count1) {

	try {
		ds_1 = std::unique_ptr<qlua::data_source>
			(new ::qlua::data_source
			(q1.CreateDataSource(sec_class_1.c_str(), sec_code_1.c_str(), interval_1)));
		if (!ds_1->SetUpdateCallback("qluacpp_candles_cb1")) {
			std::string msg1 = "Failed to set update callback on datasource: false returned";
			q1.message(msg1.c_str());
		}
	}
	catch (std::runtime_error e) {
		std::string msg1("Exception while creating datasource: ");
		msg1 += e.what();
		q1.message(msg1.c_str());
	}
}

model1::~model1() {
	if (ds_1) {
		try {
			ds_1->SetEmptyCallback();
		}
		catch (std::runtime_error e) {
			std::string msg1("Failed to set empty callback on model destruction: ");
			msg1 += e.what();
			MessageBoxA(NULL, msg1.c_str(), "Draw candles RT error", MB_OK);
		}
		/*
		// Close() returns nil instead of bool because of Quik bug, reported and will be fixed
		try {
		  ds_->Close();
		} catch (std::runtime_error e) {
		  std::string msg("Failed to close datasource on model destruction: ");
		  msg += e.what();
		  MessageBoxA(NULL, msg.c_str(), "Draw candles RT error", MB_OK);
		  }*/
	}
}

void model1::fill_candle_from_ds1(candle1& c1, const unsigned int idx1) {
	c1.idx1 = idx1;
	c1.high1 = ds_1->H(idx1);
	c1.low1 = ds_1->L(idx1);
	c1.open1 = ds_1->O(idx1);
	c1.close1 = ds_1->C(idx1);
	c1.volume1 = ds_1->V(idx1);
	//auto _last = c.close();
	try {
		std::stringstream ss1;
		auto t1 = ds_1->T(idx1);
		ss1 << std::setfill('0') << std::setw(4) << t1.year << "/"
			<< std::setfill('0') << std::setw(2) << t1.month << "/"
			<< std::setfill('0') << std::setw(2) << t1.day << " "
			<< std::setfill('0') << std::setw(2) << t1.hour << ":"
			<< std::setfill('0') << std::setw(2) << t1.min << ":"
			<< std::setfill('0') << std::setw(2) << t1.sec << "."
			<< std::setfill('0') << std::setw(2) << t1.ms;
		c1.time1 = ss1.str();
	}
	catch (...) {
		std::cout << "Failed to store candle time" << std::endl;
	}
}

void model1::update1(const unsigned int idx1, std::vector<double>& x1) { //, vector<double>& Price
	using namespace std::chrono_literals;
	const unsigned int ds_sz1 = ds_1->Size();
	x1.resize(max_count_1 + 2);
	//auto _close_price;
	//double x = 0;
	//vector <_prices> _Data;
   // Closing_Price.resize(max_count_);
	if (ds_sz1 >= max_count_1) {
		wait1();
		if ((idx1 >= ds_sz1 - max_count_1) && (idx1 <= ds_sz1)) {
			// We don't need to receive new candles window, only update existing candle
			auto found1 = std::find_if(candles_1.begin(), candles_1.end(),
				[&idx1](const candle1& c1) {
				return c1.idx1 == idx1;
			});
			if (found1 != candles_1.end()) {
				fill_candle_from_ds1(*found1, idx1);
			}
			else {
				// We need to receive new candles window
				candles_1.clear();
				last_price_1.clear();
				candles_1.reserve(max_count_1);
				last_price_1.reserve(max_count_1);
				int u = 0;
				for (size_t i = ds_sz1 - max_count_1 + 1; i < ds_sz1 + 1; ++i) {
					candle1 c1;
					fill_candle_from_ds1(c1, i);  //Closing_Price[i] = c.close;
					candles_1.push_back(c1);
					last_candle_idx_1 = i;
					double xx = max_count_1;
					//x.push_back(c.close);
					x1[u] = c1.close1;
					last_price_1.push_back(c1.close1);		  //_Data[i]._last_price = x;
					u++;
				}
			}

			// Recalculate min/max
			min_price_1 = std::numeric_limits<double>::max();
			max_price_1 = std::numeric_limits<double>::min();
			min_volume_1 = std::numeric_limits<double>::max();
			max_volume_1 = std::numeric_limits<double>::min();
			for (const auto& c1 : candles_1) {
				if (min_price_1 > c1.low1) min_price_1 = c1.low1;
				if (max_price_1 < c1.high1) max_price_1 = c1.high1;
				if (min_volume_1 > c1.volume1) min_volume_1 = c1.volume1;
				if (max_volume_1 < c1.volume1) max_volume_1 = c1.volume1;
			}
			on_new_data1();
		}
		notify1();
	}
}

size_t& model1::max_count1() {
	return max_count_1;
}

std::string& model1::sec_class1() {
	return sec_class_1;
}

std::string& model1::sec_code1() {
	return sec_code_1;
}

unsigned int& model1::interval1() {
	return interval_1;
}

auto model1::candles1() const -> const std::vector<candle1>& {
	return candles_1;
}

double model1::max_price1() const {
	return max_price_1;
}

double model1::min_price1() const {
	return min_price_1;
}

double model1::max_volume1() const {
	return max_volume_1;
}

double model1::min_volume1() const {
	return min_volume_1;
}

void model1::notify1() {
	std::unique_lock<std::mutex> lock1(mutex_1);
	ready_1 = true;
	lock1.unlock();
	cv_1.notify_one();
}

void model1::wait1() {
	std::unique_lock<std::mutex> lock1(mutex_1);
	cv_1.wait(lock1, [this]() {return ready_1;});
	ready_1 = false;
}
