#pragma once
#pragma once


#include <atomic>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
//#include <math>
#include <qluacpp/qlua>

using std::vector;



struct model1 {

	struct candle1 {
		double high1;
		double low1;
		double open1;
		double close1;
		double volume1;
		double idx1;
		std::string time1;
	};

	model1(const qlua::api& q1,
		const std::string& sec_class1, const std::string& sec_code1, const unsigned int interval1,
		const size_t max_count1);
	~model1();
	void update1(unsigned int idx1, std::vector<double>&); //, std::vector<double>&, const std::vector<double>& Closing_Price

	const std::vector<candle1>& candles1() const;
	double min_price1() const;
	double max_price1() const;
	double min_volume1() const;
	double max_volume1() const;

	void wait1();
	void notify1();
	size_t& max_count1();
	std::string& sec_class1();
	std::string& sec_code1();
	unsigned int& interval1();


	std::function<void()> on_new_data1 = []() { return; };
private:
	std::string sec_class_1;
	std::string sec_code_1;
	unsigned int interval_1;
	size_t max_count_1{ 25 };

	std::unique_ptr<qlua::data_source> ds_1;
	unsigned int last_candle_idx_1{ 0 };

	std::vector<candle1> candles_1;
	std::vector<double> last_price_1;
	double min_price_1;
	double max_price_1;
	double min_volume_1;
	double max_volume_1;

	std::condition_variable cv_1;
	bool ready_1{ true };
	std::mutex mutex_1;

	// Fills candle data from candle in datasource by index
	void fill_candle_from_ds1(candle1& c1, const unsigned int idx1);

};
