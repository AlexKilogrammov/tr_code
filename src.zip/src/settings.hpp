#pragma once

struct settings_record {
  // Candidates refresh period
  size_t candidates_refresh_timeout{10};
  // Order size in lots size for single transaction
  size_t my_order_size{3};
  // What volume to ignore cumulatively when calculating spread in level 2 bid/ask quotes; in multiples of my_lot_size
  double vol_ignore_coeff{1.0};
  // Consider candidates only if the volume is greater than this number
  double min_volume{1.0};
  // Consider candidates only if spread ratio (1 - ask/bid) is greater than this number
  double min_spread{0.00000001};
  // Max number of instruments to consider as new candidates 
  size_t num_candidates{10};
  // New order speed limit
  size_t max_new_orders_per_hour{3600 * 10};

  // Interval for candles
  std::string interval{ "INTERVAL_M1" };
  // Count of candles to keep
  size_t max_count{ 20 };
  // Rate
  double rate{ 0.06 };
  // Divs
  double divs{ 0.1 };
  // Strike
  double strike{ 241 };
  // Delta in days per year
  double dt{ 30.0 / 365 };
  // Window size
  size_t window{ 20 };
  // Volume multiplyier in sigma
  double vol_mult{ 0.1 };
  // Volume multiplyier in result volume
  double volume_mult{ 10 };
  // Get lot size from client first
  int lot_size{ 10 };
};
