#include "state.hpp"
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <vector>

#include <iostream>

#include "bot.hpp"
#include "status.hpp"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

state::state() :
  b_(bot::instance()) {
}

void state::set_lua_state(const lua::state& l) {
  l_ = l;
  q_ = std::unique_ptr<qlua::extended>(new qlua::extended(l));
}

void state::refresh_available_instrs() {
  // Get string with all classes
  auto classes = q_->getClassesList();
  if (classes != nullptr) {
    std::string class_name;
    std::vector<std::string> all_classes;
    char* ptr = (char*)classes;
    while (strlen(ptr) > 0) {
      if (*ptr == ',') {
        all_classes.push_back(class_name);
        class_name = "";
      } else class_name += *ptr;
      ++ptr;
    }
    for (const auto& class_name : all_classes)
      refresh_available_instrs(class_name);
  }
}

void state::refresh_available_instrs(const std::string& class_name) {
  try {
    auto class_secs = q_->getClassSecurities(class_name);
    char* ptr = (char*)class_secs;
    std::string sec_name;
    while (strlen(ptr) > 0) {
      if (*ptr == ',') {
        all_instrs.insert({class_name, sec_name});
        sec_name = "";
      } else sec_name += *ptr;
      ++ptr;
    }
  } catch (std::exception e) {
    bot::terminate(*q_, "l2q_spread_bot: failed to run getClassInfo for " +
              class_name + ", exception: " + e.what());
  }
}

void state::filter_available_instrs_quik_junior() {
  auto it = all_instrs.begin();
  auto end = all_instrs.end();
  using class_info = const lua::entity<lua::type_policy<qlua::table::class_info_getClassInfo>>&;
  using depo_limits = const lua::entity<lua::type_policy<qlua::table::depo_limits>>&;
   std::vector<std::string> good_names{"SBER", "LKOH"/*, "GMKN", "ROSN", "SBERP", "MGNT", "AFLT", "BANE", "BANEP", "MTLR"*/};
  while (it != end) {
    if (std::find(good_names.begin(), good_names.end(), it->second) == good_names.end()) {
      all_instrs.erase(it++);
    } else {
		// Load current positions info
		std::string class_name = it->first;
		auto n = q_->getNumberOf<::qlua::table::depo_limits>();
		for (int i = 0; i < n; i++) {
			q_->getItem<::qlua::table::depo_limits>(i, [&](depo_limits dl) {
				if (dl().sec_code() == it->second) {
					instrs[std::make_pair(it->first, it->second)].balance = trunc(dl().currentbal()) / settings_.lot_size;
				}
			});
		}
      ++it;
    }
  }
}

void state::init_client_info() {
  try {
    auto n = q_->getNumberOf<::qlua::table::client_codes>();
    if (n < 1) {
      bot::terminate(*q_, "l2q_spread_bot: too few client codes!");
    } else {
      using client_code_entity = const lua::entity<lua::type_policy<qlua::table::client_codes>>&;
      using trade_account_entity = const lua::entity<lua::type_policy<qlua::table::trade_accounts>>&;
      q_->getItem<::qlua::table::client_codes>(0, [this] (client_code_entity c) {
          client_code = c();
        });
      n = q_->getNumberOf<::qlua::table::trade_accounts>();
      for (unsigned int i = 0; i < n; ++i) {
        q_->getItem<::qlua::table::trade_accounts>(i, [this] (trade_account_entity e) {
            auto trdaccid = e().trdaccid();
            auto class_codes = e().class_codes();
            while (class_codes[0] == '|') class_codes = class_codes.substr(1, class_codes.size() - 1);
            size_t start = 0;
			std::string class_name;
            for (size_t k = 0; k < class_codes.size(); ++k) {
              if (class_codes[k] == '|') {
                if (k > start) {
                  class_name = class_codes.substr(start, k - start);
                  start = k + 1;
                  class_to_accid[class_name] = trdaccid;
                }
              }
            }
          });
      }
    }
  } catch (std::exception e) {
    bot::terminate(*q_, "l2q_spread_bot: failed to get client info for, exception: " + std::string(e.what()));
  }
}

void state::request_bid_ask() {
  for (const auto& instr : all_instrs) {
    try {
      const auto& class_name = instr.first.c_str();
      const auto& sec_name = instr.second.c_str();
      q_->CancelParamRequest(class_name, sec_name, "BID");
      q_->CancelParamRequest(class_name, sec_name, "OFFER");
      q_->CancelParamRequest(class_name, sec_name, "VALTODAY");
      q_->ParamRequest(class_name, sec_name, "BID");
      q_->ParamRequest(class_name, sec_name, "OFFER");
      q_->ParamRequest(class_name, sec_name, "VALTODAY");
    } catch (std::exception e) {
      bot::terminate(*q_, "l2q_spread_bot: failed to cancel/request bid/ask parameter for " +
        instr.first + "/" + instr.second + ", exception: " +e.what());
    }
  }
}

void state::choose_candidates() {

	/*const auto& instr = all_instrs;
  instr.first.c_str() = "TQBR";*/

  using param_entity = const lua::entity<lua::type_policy<qlua::table::current_trades_getParamEx>>&;

  std::vector<std::pair<instrument, double>> spreads;
  for (const auto& instr : all_instrs) {
    try {
      bool instr_alive{false}; // Instrument has been traded today
      q_->getParamEx2(instr.first, instr.second, "VALTODAY",
                      [this, &instr_alive] (param_entity param) {
                        if ((param().param_type() <= 2) && (param().param_value() > b_.settings().min_volume))
                          instr_alive = true;
                      });
      if (instr_alive) {
        double bid{0.0};
        double ask{0.0};
        q_->getParamEx2(instr.first, instr.second, "BID",
                        [&bid] (param_entity param) {
                          if ((param().param_type() <= 2)) {
                            bid = param().param_value();
                          }
                        });
        q_->getParamEx2(instr.first, instr.second, "OFFER",
                        [&ask] (param_entity param) {
                          if ((param().param_type() <= 2)) {
                            ask = param().param_value();
                          }
                        });
        if ((ask != 0.0) && (bid != 0.0)) {
          double spread_ratio = ask/bid - double{1.0};
          if (spread_ratio > b_.settings().min_spread) spreads.push_back({instr, spread_ratio});
        }
      }
    } catch (std::exception e) {
      bot::terminate(*q_, "l2q_spread_bot: failed to evaluate spread ratio for " +
                   instr.first + "/" + instr.second + ", exception: " + e.what());
    }
  }
  std::sort(spreads.begin(), spreads.end(), [] (const std::pair<instrument, double>& a,
                                                const std::pair<instrument, double>& b) {
              return a.second > b.second;
            });
  // Cycle through no more than num_candidates best instruments
  for (size_t i = 0; (i < b_.settings().num_candidates) && (i < spreads.size()); ++i) {
    const auto& instr = spreads[i].first;
    auto found = instrs.find(instr);
    // If it's a new instrument or an old deactivated
    if ((found == instrs.end()) || ((found != instrs.end()) && (found->second.spread == 0) && (!found->second.l2q_subscribed))) {
      // Add it and initialize spread to info from on_param
      instrs[instr].spread = spreads[i].second;
	  instrs[instr].model = std::shared_ptr<model>(new model(*q_, instr.first, instr.second, q_->constant<unsigned int>(settings_.interval), settings_.max_count));
      q_->getParamEx2(instr.first, instr.second, "SEC_PRICE_STEP",
                      [this, &instr] (param_entity param) {
                        instrs[instr].sec_price_step = param().param_value();
                      });
    }
  }
  act();
}

void state::remove_inactive_instruments() {
  std::vector<instrument> removed;
  for (const auto& ip : instrs) {
    auto& instr = ip.first;
    auto& info = ip.second;
    if ((info.balance == 0) &&
        (info.buy_order.new_trans_id == 0) &&
        (info.buy_order.cancel_trans_id == 0) &&
        (info.sell_order.new_trans_id == 0) &&
        (info.sell_order.cancel_trans_id == 0) &&
        (info.l2q_subscribed == false) &&
        (info.spread == 0.0)) {
      removed.push_back(instr);
    }
  }
  for (const auto& r : removed) { instrs.erase(r); }
}

void state::update_l2q_subscription(const instrument& instr, instrument_info& info) {
  // Consider removing unneeded subscriptions
  if (info.l2q_subscribed &&
      (info.buy_order.new_trans_id == 0) &&
      (info.buy_order.order_key == 0) &&
      (info.sell_order.new_trans_id == 0) &&
      (info.sell_order.order_key == 0) &&
      (info.balance == 0) &&
      (info.spread < b_.settings().min_spread)) {
    // Sometimes Quik for some unknown reason fails to unsubscribe. Let's check that it thinks we are subscribed first
    if (q_->IsSubscribed_Level_II_Quotes(instr.first, instr.second)) {
      if (q_->Unsubscribe_Level_II_Quotes(instr.first, instr.second)) {
        info.l2q_subscribed = false;
        info.spread = 0;
        info.sell_order.estimated_price = 0;
        info.buy_order.estimated_price = 0;
      }
    } else {
      bot::terminate(*q_, "We are subscribed to " + instr.first + "/" + instr.second + ", but Quik doesn't think so!");
    }
  } else {
    // Consider adding subscriptions, if we are not subscribed yet
    if (!info.l2q_subscribed) {
      if (q_->Subscribe_Level_II_Quotes(instr.first, instr.second)) {
        info.l2q_subscribed = true;
      } else {
        bot::terminate(*q_, "Could not subscribe to " + instr.first + "/" + instr.second);
      }
    }
  }
}

void state::request_new_order(const instrument& instr, const instrument_info& info,
                                  order_info& order, const std::string& operation, const size_t qty) {
  // Check protective time limits
  try {
    // Calculate decimal precision for the price
    //std::string price_step = std::to_string(info.sec_price_step);
    //auto pos = std::string::npos;
    //pos = price_step.find_last_of('.');
    //if (pos != std::string::npos) price_step = price_step.substr(pos + 1, price_step.size());
    //pos = price_step.find_last_of(',');
    //if (pos != std::string::npos) price_step = price_step.substr(pos + 1, price_step.size());
    //while ((price_step.size() > 0) && (price_step[price_step.size() - 1] == '0')) price_step.pop_back();
    //auto precision = price_step.size();

    //auto price = order.estimated_price;


    //std::string price_s;
    //if (precision > 0) {
    //  std::stringstream price_ss;
    //  price_ss << std::fixed;
    //  price_ss << std::setprecision(precision);
    //  price_ss << price;
    //  price_s = price_ss.str();
    //} else {
    //  price_s = std::to_string(int(price));
    //}
    //
    auto buy_sell = q_->CalcBuySell(instr.first, instr.second,
                                    client_code, class_to_accid[instr.first],
                                    0, true, true);
    const auto& max_qty = std::get<0>(buy_sell);
    /*    std::cout << " est price " << order.estimated_price
              << " sec_price_step " << info.sec_price_step
              << " precision " << precision
              << " qty " << qty
              << " max qty " << max_qty
              << " comission " << std::get<1>(buy_sell)
              << " price_s " << price_s     
              << " price " << price << std::endl; */
    //if ((qty > 0) && (qty <= max_qty) && (price != 0.0)) {
    if ((qty > 0) && (qty <= max_qty)) {
      auto trans_id = next_trans_id();

      std::map<std::string, std::string> trans = {
        {"ACCOUNT", class_to_accid[instr.first]},
        {"CLIENT_CODE", client_code},
        {"CLASSCODE", instr.first},
        {"SECCODE", instr.second},
        {"TRANS_ID", std::to_string(trans_id)},
        {"QUANTITY", std::to_string(qty)},
        {"OPERATION", operation},
		{"TYPE", "M"},
        {"PRICE", "0"},
        {"ACTION", "NEW_ORDER"}
      };
      q_->sendTransaction(trans);
      order.new_trans_id = trans_id;
      order.placed_price = 0;
      // Save transaction time for time limit
      trans_times_within_hour.push_back(std::chrono::time_point<std::chrono::steady_clock>());
    }
  } catch (std::exception e) {
    bot::terminate(*q_, "l2q_spread_bot: error calculating/sending buy, exception: " + std::string(e.what()));
  }
}

void state::request_kill_order(const instrument& instr, order_info& order) {
  // Check there's an order and there's no previous cancel request pending
  if ((order.order_key != 0) && (order.cancel_trans_id == 0)) {
    try {
      auto trans_id = next_trans_id();
      std::map<std::string, std::string> trans = {
        {"CLASSCODE", instr.first},
        {"SECCODE", instr.second},
        {"TRANS_ID", std::to_string(trans_id)},
        {"ACTION", "KILL_ORDER"},
        {"ORDER_KEY", std::to_string(order.order_key)}
      };
      q_->sendTransaction(trans);
      order.cancel_trans_id = trans_id;
      // Save transaction time for time limit
      trans_times_within_hour.push_back(std::chrono::time_point<std::chrono::steady_clock>());
    } catch (std::exception e) {
      bot::terminate(*q_, "l2q_spread_bot: error sending cancel buy transaction, exception: " + std::string(e.what()));
    }
  }
}
  
bool state::trans_times_limits_ok() {
  if (trans_times_within_hour.size() == 0) return true;
  auto now = std::chrono::time_point<std::chrono::steady_clock>();
  while (trans_times_within_hour.front() < now - std::chrono::hours{1})
    trans_times_within_hour.pop_front();
  return trans_times_within_hour.size() < 50;
}

void state::act() {
  remove_inactive_instruments();
  for (auto& ip : instrs) {
    auto& instr = ip.first;
    auto& info = ip.second;
    //// If we have an active buy order
    //if ((info.buy_order.order_key != 0)) {
    //  // Kill buy order if spread became low
    //  if (info.spread < b_.settings().min_spread) {
    //    request_kill_order(instr, info.buy_order);
    //  }
    //}
    //// If we have an active sell order
    //if ((info.sell_order.order_key != 0)) {
    //  // Kill sell order if spread became low
    //  if (info.spread < b_.settings().min_spread) {
    //    request_kill_order(instr, info.sell_order);
    //  }
    //}

	if (info.model == NULL) {
		// Not yet initialized
		continue;
	}
	int res = floor(settings_.volume_mult * _volatility(settings_.window, info, settings_.vol_mult, settings_.dt));
	std::cerr << "<" + instr.first + ":" + instr.second + ">: " + info.to_string() + " - " + std::to_string(res);
	//q_->message("<" + instr.first + ":" + instr.second + ">: " + info.to_string() + " - " + std::to_string(res));
	if (res < info.balance && 
		(info.sell_order.order_key == 0) &&
		(info.sell_order.new_trans_id == 0) && (info.sell_order.cancel_trans_id == 0) &&
		(info.model->candles().size() >= settings_.max_count)) {
		// we need less volume - sell difference
		request_new_order(instr, info, info.sell_order, "S", info.balance - res);
	}
	else if (res > info.balance &&
		(info.buy_order.order_key == 0) &&
		(info.buy_order.new_trans_id == 0) && (info.buy_order.cancel_trans_id == 0) &&
		(info.model->candles().size() >= settings_.max_count)) {
		// we need more volume - buy difference
		request_new_order(instr, info, info.buy_order, "B", res - info.balance);
	}

    // Do we need to place a new buy order?
    //if ((info.buy_order.order_key == 0) &&
    //    (info.spread >= b_.settings().min_spread) &&
    //    (info.buy_order.estimated_price != 0.0) &&
    //    (info.buy_order.new_trans_id == 0) && (info.buy_order.cancel_trans_id == 0)) {
    //  const auto qty = b_.settings().my_order_size - info.balance;
    //  if ((qty > 0) && (trans_times_limits_ok())) {
    //    request_new_order(instr, info, info.buy_order, "B", qty);
    //  }
    //}
    //// Do we need to place a new sell order?
    //if ((info.sell_order.order_key == 0) &&
    //    (info.spread >= b_.settings().min_spread) &&
    //    (info.sell_order.estimated_price != 0.0) &&
    //    (info.sell_order.new_trans_id == 0) && (info.sell_order.cancel_trans_id == 0)) {
    //  const auto qty = info.balance;
    //  if (qty > 0) {
    //    request_new_order(instr, info, info.sell_order, "S", qty);
    //  }
    //}
    
    update_l2q_subscription(instr, info);
  }
  b_.update_status = true;
}

void state::on_order(unsigned int trans_id, unsigned int order_key, const unsigned int flags, const size_t qty, const size_t balance, const double price) {
  const instrument* instr{nullptr};
  instrument_info* info{nullptr};

  if (trans_id != 0) {
	  auto found = std::find_if(instrs.begin(), instrs.end(), [trans_id](const std::pair<instrument, instrument_info>& ip) {
		  const auto& info = ip.second;
		  return (info.buy_order.new_trans_id == trans_id)
			  || (info.sell_order.new_trans_id == trans_id)
			  || (info.buy_order.cancel_trans_id == trans_id)
			  || (info.sell_order.cancel_trans_id == trans_id);
	  });
	  if (found != instrs.end()) {
		  instr = &found->first;
		  info = &found->second;
	  }
  }

  if ((instr == nullptr) && (order_key != 0)) {
	  // Could not find by trans_id, search by order_key if it's not 0
	  auto found = std::find_if(instrs.begin(), instrs.end(), [order_key](const std::pair<instrument, instrument_info>& ip) {
		  const auto& info = ip.second;
		  return (info.buy_order.order_key == order_key) || (info.sell_order.order_key == order_key);
	  });
	  if (found != instrs.end()) {
		  instr = &found->first;
		  info = &found->second;
	  }
  }
    
  // If order was found in bot's orders
  if (instr != nullptr) {
    order_info* order{nullptr};
    // Choose the right order object
    if (flags & 4) { // If it's a sell order
      order = &info->sell_order;
    } else { // It's a buy order
      order = &info->buy_order;
    }
    if (!(flags & 1) && !(flags & 2)) { // Executed
      if (flags & 4) {
        // Sold, decrement balance
        info->balance -= qty;
      } else {
        // Bought, increment balance
        info->balance_price = (info->balance * info->balance_price + qty * price) /
          (info->balance + qty);
        info->balance += qty;
      }
      *order = {};
    }
    else if (flags & 2) { // Removed
      *order = {};
    }
    else if (flags & 1) { // Active
      order->order_key = order_key;
    } else if (!(flags &1)) { // Inactive
      order->order_key = 0;
    }
    act();
  }
}

void state::on_quote(const std::string& class_code, const std::string& sec_code) {
  auto found = instrs.find(instrument{class_code, sec_code});
  if (found != instrs.end()) {
    auto& instr = found->first;
    auto& info = found->second;
    // Check that instrument is in dirty state (no unfinished requests)
    bool dirty{false};
    // Sent sell order, but no order number yet -> dirty
    if ((info.sell_order.new_trans_id != 0) && (info.sell_order.order_key == 0)) dirty = true;
    // Sent buy order, but no order number yet -> dirty
    if ((info.buy_order.new_trans_id != 0) && (info.buy_order.order_key == 0)) dirty = true;
    if (!dirty) {
      try {
        q_->getQuoteLevel2(class_code, sec_code,
                           [this, &instr, &info] (const ::qlua::table::level2_quotes& quotes) {
                             auto bid = quotes.bid();
                             auto offer = quotes.offer();

                             double acc{0.0};
                             double my_bid_price{0.0};
                             double my_ask_price{0.0};
                             if (bid.size() > 0) {
                               size_t i{0};
                               for (i = 0; i < bid.size(); ++i) {
                                 const auto& rec = bid[bid.size() - 1 - i];
                                 const double qty = atof(rec.quantity.c_str());
                                 const double price = atof(rec.price.c_str());
                                 auto new_acc = acc + qty * price;
                                 if (info.buy_order.order_key != 0) {
                                   // Don't count our own order
                                   new_acc -= info.buy_order.qty * info.buy_order.placed_price;
                                 }
                                 my_bid_price = atof(rec.price.c_str()) + info.sec_price_step;
                                 //                                 std::cout << "  Instr " << instr.first << "/" << instr.second
                                 //        << " qty " << qty << " price " << price << " new_acc " << new_acc << " my b p " << my_bid_price << std::endl;
                                 if (new_acc > (b_.settings().my_order_size * my_bid_price * b_.settings().vol_ignore_coeff)) {
                                   break;
                                 } else {
                                   acc = new_acc;
                                 }
                               }
                             }
                             //                             std::cout << "My bid price " << my_bid_price << ::std::endl;

                             acc = 0.0;
                             if (offer.size() > 0) {
                               size_t i{0};
                               for (i = 0; i < offer.size(); ++i) {
                                 const auto& rec = offer[i];
                                 const double qty = atof(rec.quantity.c_str());
                                 const double price = atof(rec.price.c_str());
                                 auto new_acc = acc + qty * price;
                                 if (info.sell_order.order_key != 0) {
                                   // Don't count our own order
                                   new_acc -= info.sell_order.qty * info.sell_order.placed_price;
                                 }
                                 my_ask_price = atof(rec.price.c_str()) - info.sec_price_step;
                                 if (new_acc >
                                     (b_.settings().my_order_size * my_ask_price * b_.settings().vol_ignore_coeff)) {
                                   break;
                                 } else {
                                   acc = new_acc;
                                 }
                               }
                             }

                             if ((my_bid_price > 0) && (my_ask_price > 0)) {
                               info.buy_order.estimated_price = round(my_bid_price / info.sec_price_step) * info.sec_price_step;
                               info.sell_order.estimated_price = round(my_ask_price / info.sec_price_step) * info.sec_price_step;
                               info.spread = my_ask_price/my_bid_price - 1.0;
							   info.spot_ask = my_ask_price;
							   info.spot_bid = my_bid_price;
                               //                               std::cout << "Set buy " << my_bid_price << " sell " << my_ask_price << " spread " << info.spread << std::endl;
                             } else {
                               info.buy_order.estimated_price = 0;
                               info.sell_order.estimated_price = 0;
                               info.spread = 0;
							   info.spot_ask = 0;
							   info.spot_bid = 0;
                             }
                             act();
                           });
      } catch (std::exception e) {
        bot::terminate(*q_, "l2q_spread_bot: error sending cancel buy transaction, exception: " + std::string(e.what()));
      }
    }
  }
}

double state::_volatility(int window, const state::instrument_info& info, double vol_mult, double dt) {
	double _aver = 0.0;
	std::vector<double> _ret(window);
	_return(info.model->candles(), _ret);
	for (int i = 0; i < window; i++) {
		_aver += _ret[i];
	}
	_aver /= window;
	double sum = 0.0;
	for (int i = 0; i < window; i++) {
		sum += (_ret[i] - _aver) * (_ret[i] - _aver);
	}
	double sigma = vol_mult * sqrt(sum / window);

	// pass forward
	return delta(settings_.rate, settings_.divs, info.spot_bid, settings_.strike, sigma, dt);
}

double state::delta(double rate, double divs, double price, double strike, double sigma, double dt) {
	double d_1 = (log(price / strike) + dt * (rate - divs - (sigma * sigma) / 2)) / (sigma * sqrt(dt));
	return exp(-divs * dt) * value(d_1);
}

void state::_return(const std::vector<model::candle>& price, std::vector<double>& res) {
	for (int i = 1; i < price.size(); i++) {
		res[i] = log(price[i].open / price[i - 1].open);
	}
}

double state::value(double d) {
	const double a1 = 0.319381530;
	const double a2 = -0.356563782;
	const double a3 = 1.781477937;
	const double a4 = -1.821255978;
	const double a5 = 1.330274429;
	const double gamma = 0.2316419;
	const double k1 = 1 / (1 + d * gamma);
	const double k2 = 1 / (1 - d * gamma);
	const double normalprime = (1 / (sqrt(2 * M_PI))) * exp(-d * d / 2);
	double res;
	if (d >= 0) {
		res = 1 - normalprime * (a1 * k1 + a2 * pow(k1, 2) + a3 * pow(k1, 3) + a4 * pow(k1, 4) + a5 * pow(k1, 5));
	} else {
		res = normalprime * (a1 * k2 + a2 * pow(k2, 2) + a3 * pow(k2, 3) + a4 * pow(k2, 4) + a5 * pow(k2, 5));
	}
	//cout << " value " << value << endl << endl;
	return res;
}

double state::density(double x, double mu, double sigma)
{
	return (1.0 / sqrt(2.0 * M_PI * sigma)) * exp(-(0.5 * pow((x - mu), 2.0)) / (sigma));
}

void state::on_stop() {
  for (auto& ip : instrs) {
    // Kill any pending orders
    if (ip.second.buy_order.order_key != 0) request_kill_order(ip.first, ip.second.buy_order);
    if (ip.second.sell_order.order_key != 0) request_kill_order(ip.first, ip.second.sell_order);
  }
}



unsigned int state::next_trans_id() {
  ++next_trans_id_;
  return next_trans_id_;
}
