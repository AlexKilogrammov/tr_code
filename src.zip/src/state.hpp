#pragma once

#include <atomic>
#include <chrono>
#include <deque>
#include <map>
#include <mutex>
#include <set>

#include <qluacpp/extended>

#include "status.hpp"
#include "model.hpp"
#include "settings.hpp"

struct bot;

struct state {
  // Type for unique instrument descriptor = <class_name, sec_class>
  using instrument = std::pair<std::string, std::string>;

  struct order_info {
    unsigned int new_trans_id{0};
    unsigned int order_key{0};
    unsigned int cancel_trans_id{0};
    unsigned int qty;
    double estimated_price; // Estimated optimal price
    double placed_price; // Price for acive order
	std::string to_string() {
		return std::string("{") +
			"new_trans_id=" + std::to_string(new_trans_id) +
			", order_key=" + std::to_string(order_key) +
			", cancel_trans_id=" + std::to_string(cancel_trans_id) +
			", qty=" + std::to_string(qty) +
			", estimated_price=" + std::to_string(estimated_price) +
			", placed_price=" + std::to_string(placed_price) +
			"}";
	}
  };
  
  struct instrument_info {
	  std::string firm_id{ "" };
    double sec_price_step{0.0};
    // How many lots on balance are operated by this bot    
    int balance{0};
    double balance_price{0.0};
    // Bot's buy order
    order_info buy_order;
    // Bot's sell order
    order_info sell_order;
    // Are level2 quotes subscribed to?
    bool l2q_subscribed{false};
    // Last known spread
    double spread{0.0};
	// Counted hedge metric
	double quant{0.0};
	double spot_ask{ 0.0 };
	double spot_bid{ 0.0 };
	// Candles
	std::shared_ptr<model> model = NULL;

	std::string to_string() {
		return std::string("{") +
			"sec_price_step=" + std::to_string(sec_price_step) +
			", balance=" + std::to_string(balance) +
			", balance_price=" + std::to_string(balance_price) +
			", buy_order=" + buy_order.to_string() +
			", sell_order=" + sell_order.to_string() +
			", l2q_subscribed=" + std::to_string(l2q_subscribed) +
			", spread=" + std::to_string(spread) +
			", quant=" + std::to_string(quant) +
			", spot_ask=" + std::to_string(spot_ask) +
			", spot_bid=" + std::to_string(spot_bid) + 
			"}";
	}
  };

  state();

  // Set lua::state and qlua::extended private members
  void set_lua_state(const lua::state& l);
  // Update all class name/security name pairs for all classes
  void refresh_available_instrs();
  // Update all class name/security name pairs for a class
  void refresh_available_instrs(const std::string& class_name);
  // Quik Junior does not really update info for most instruments.
  // Filter available instrs to contain only those known to be updated.
  void filter_available_instrs_quik_junior();
  // Initialize client code and account
  void init_client_info();
  // Request best bid/ask parameters for all_instrs_
  void request_bid_ask();
  // Select candidates with highest spread and trade volume > 0
  void choose_candidates();
  // Remove instruments that are not active
  void remove_inactive_instruments();
  // Send request to make a new buy order
  void request_new_order(const instrument& instr, const instrument_info& info, order_info& order, const std::string& operation, const size_t qty);
  // Send request to kill existing order
  void request_kill_order(const instrument& instr, order_info& order);
  // Remove unneeded subscription, or make a new one if needed
  void update_l2q_subscription(const instrument& instr, instrument_info& info);
  // Is it ok to make a new transaction within time period
  bool trans_times_limits_ok();
  
  // Consider taking action: make transaction, remove transaction, update subscriptions, etc.
  void act();

  // Handle on_order
  void on_order(unsigned int trans_id, unsigned int order_key, unsigned int flags, const size_t qty, const size_t balance, const double price);
  // Handle level 2 quotes change
  void on_quote(const std::string& class_code, const std::string& sec_code);
  // Calculate value
  double value(double d);
  double density(double x, double mu, double sigma);
  // Handle on_stop event to deinitialize
  void on_stop();
  // Update instr
 
  // Get new unique transaction id
  unsigned int next_trans_id();

  std::string client_code; // Client code
  std::map<std::string, std::string> class_to_accid; // Which account to use for trading a particular class
  std::set<instrument> all_instrs;  // All available instruments
  std::map<instrument, instrument_info> instrs; // Active instruments
  std::deque<std::chrono::time_point<std::chrono::steady_clock>> trans_times_within_hour; // Time of each transaction within last hour
  settings_record settings_;

private:
  lua::state l_;
  std::unique_ptr<qlua::extended> q_;
  bot& b_;

  unsigned int next_trans_id_{0};

  void _return(const std::vector<model::candle>& price, std::vector<double>& res);
  double _volatility(int window, const state::instrument_info& info, double vol_mult, double dt);
  double delta(double rate, double divs, double price, double strike, double sigma, double dt);
};

