#pragma once

#include <qluacpp/qlua>

struct wa_table {
  // Creates QLUA table
  void create(const qlua::api& q, const char* name);
  // Updates table with the data and timestamps it
  void update(const qlua::api& q,
              const double bid_wap, const double bid_quant,
              const double ask_wap, const double ask_quant, const std::vector<double> last_price);

private:
  int table_id_{0};

  // Table column ids
  const int col_desc_{1};
  const int col_value_{2};

  // Table row ids
  int row_time_{-1};
  int row_bid_wap_{-1};
  int row_bid_quant_{-1};
  int row_ask_wap_{-1};
  int row_ask_quant_{-1};
  int row_last_price_{-1};
};

struct wa_table1 {
	// Creates QLUA table
	void create1(const qlua::api& q1, const char* name1);
	// Updates table with the data and timestamps it
	void update1(const qlua::api& q1,
		const double bid_wap1, const double bid_quant1,
		const double ask_wap1, const double ask_quant1, const std::vector<double> last_price1);

private:
	int table_id_1{ 0 };

	// Table column ids
	const int col_desc_1{ 1 };
	const int col_value_1{ 2 };

	// Table row ids
	int row_time_1{ -1 };
	int row_bid_wap_1{ -1 };
	int row_bid_quant_1{ -1 };
	int row_ask_wap_1{ -1 };
	int row_ask_quant_1{ -1 };
	int row_last_price_1{ -1 };
};

class QuikConnector {
public:
	double MidMarket(double, double);
};